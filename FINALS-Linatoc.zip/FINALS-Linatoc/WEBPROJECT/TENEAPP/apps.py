from django.apps import AppConfig


class TeneappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TENEAPP'
